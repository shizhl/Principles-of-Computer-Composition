# README

**实验一文件说明以及主要文件作用如下所示**

```cpp
│ README.md    项目文件说明MarkDown版
│ README.pdf   项目文件说明PDF版
│ 四班-201900130133-施政良-实验一.pdf 实验一实验报告，用于记录实验原理，关键步骤、实验进度以及实验新得体会   
├─EXP  
│  add8.bdf  封装八位加法器
│  add8.bsf  八位加法器原件
│  ALU.bdf   封装ALU逻辑运算单元
│  ALU.bsf   ALU逻辑运算单元原件
│  CROM.bsf  微指令存储器
│  CROM.cmp
│  crom.mif  微指令存储器初始化文件
│  CROM.qip
│  CROM.vhd
│  exp1.bdf  实验一总实验电路图
│  exp1.qpf 
│  exp1.qsf
│  exp1.qws
│  IR.bdf   封装指令寄存器IR
│  IR.bsf   指令寄存器IR原件
│  UPC.bdf  封装微指令寄存器μPC
│  UPC.bsf  微指令寄存器μPC原件
│  Waveform.vwf  仿真测试文件1，用于调试
│  Waveform1.vwf  仿真测试文件2，用于调试
├─db   文件夹
├─incremental_db  文件夹
├─output_files  文件夹
└─simulation  文件夹
```

