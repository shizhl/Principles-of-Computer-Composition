[toc]

# README

计算机组成原理课程设计实验二项目文件说明

```cpp
│ README.md               //项目文件说明MarkDown版本
│ README.pdf              //项目文件说明PDF版本
│ 四班-施政良-201900130133-实验二项目报告.pdf   //实验二报告
├─EXP2
│  └─model.bdf               //模型机原图设计，为了方便观察，在model.bdf文件中去掉了原设计图中的调试输出器件
│    |  clock.bdf               //时钟发生器设计图
│    |  clock.bsf               //时钟发生器原件
│    |  CROM.bsf                //CROM相关文件
│    |  CROM.cmp
│    |  crom.mif
│    |  CROM.qip
│    |  CROM.vhd  
│    |  data_choose.bdf         //数据选择器
│    |  data_choose.bsf
│    |  EXP2.bdf                //项目总设计，包括调试输出器件
│    |  EXP2.qpf                
│    |  EXP2.qsf                
│    |  IR.bdf                  //指令寄存器设计图
│    |  IR.bsf                  //指令寄存器原件
│    |  MAR.bdf                 //MAR原件设计图
│    |  MAR.bsf                 //MAR原件
│    |  PC.bdf                  //程序计数器PC原件设计图
│    |  PC.bsf                  //程序计数器PC原件
│    |  R.bdf                   //寄存器R设计图
│    |  R.bsf                   //寄存器R原件
│    |  RAM.bsf                 //RAM设计相关文件
│    |  RAM.cmp
│    |  RAM.mif                 //RAM初始化文件
│    |  RAM.qip
│    |  RAM.vhd                  
│    |  TEMP.bdf                //调试输出原件设计图
│    |  TEMP.bsf                //调试输出原件
│    |  UPC.bdf                 //UPC原器件设计图
│    |  UPC.bsf                 //UPC原器件
│    |  Waveform.vwf            //虚拟波形仿真测试文件
│    |  Waveform.vwf.temp
│    |  Waveform1.vwf
│    |  Waveform1.vwf.temp
│    |  Waveform2.vwf
│    |  Waveform2.vwf.temp
├─db                       //其他文件文件夹   
├─greybox_tmp              //其他文件文件夹   
├─incremental_db           //其他文件文件夹   
│  └─compiled_partitions   //其他文件文件夹   
├─output_files             //其他文件文件夹   
└─simulation               //其他文件文件夹。用于虚拟波形仿真测试   
```



